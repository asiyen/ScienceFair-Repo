import torch
from torch import nn
import numpy as np
if __name__=='__main__':
    embeddings={}
    num_embeds={}
    count=1
    with open("",'r') as emb:
        for line in emb:
            first_space=line.index(' ')
            word=line[:first_space]
            nums=np.fromstring(line[first_space:])
            embeddings[word]=torch.from_numpy(nums).float()
            num_embeds[count]=word
            count+=1

def load_weights():
    embedding=nn.Embedding(len(num_embeds),50)

